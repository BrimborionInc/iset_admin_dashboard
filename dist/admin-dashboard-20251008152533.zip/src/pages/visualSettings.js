// (Removed - visual settings merged into configuration dashboard)
