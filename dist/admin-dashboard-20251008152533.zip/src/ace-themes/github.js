exports.isDark = false;
exports.cssClass = "ace-github";